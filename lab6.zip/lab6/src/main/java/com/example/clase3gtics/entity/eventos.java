package com.example.clase3gtics.entity;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name="eventos")
public class eventos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "eventoid")
    private int eventoid;
    @Column(name = "nombre")
    /////////
    private String nombre;
    @Column(name = "fecha")
    private Date fecha;

    public int getEventoid() {
        return eventoid;
    }

    public void setEventoid(int eventoid) {
        this.eventoid = eventoid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getAsistentes() {
        return asistentes;
    }

    public void setAsistentes(String asistentes) {
        this.asistentes = asistentes;
    }

    @Column(name = "asistentes")
    private String asistentes;
}
