package com.example.clase3gtics.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "artistas")
public class Artistas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "artistasid")
    private int artistasid;
    @Column(name = "nombre")
    private String name;
    @Column(name = "genero")
    private String genero;
    @Column(name = "telefono")
    private String phone;

    public int getArtistasid() {
        return artistasid;
    }

    public void setArtistasid(int artistasid) {
        this.artistasid = artistasid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
