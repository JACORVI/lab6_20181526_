package com.example.clase3gtics.repository;

public interface ArtistaRepository {
}
