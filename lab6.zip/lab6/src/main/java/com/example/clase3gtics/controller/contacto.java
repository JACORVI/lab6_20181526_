package com.example.clase3gtics.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/contacto")
public class contacto {

    @GetMapping("")
    public String contacto() {
        return "contacto";
    }
}
