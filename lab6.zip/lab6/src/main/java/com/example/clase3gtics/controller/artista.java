package com.example.clase3gtics.controller;

import com.example.clase3gtics.repository.ArtistaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/artista")
public class artista {
    final ArtistaRepository artistaRepository;

    public artista(ArtistaRepository artistaRepository) {
        this.artistaRepository = artistaRepository;
    }
}
