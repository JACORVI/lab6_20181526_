package com.example.clase3gtics.controller;


import com.example.clase3gtics.repository.EventosRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/evento")
public class Eventos {
    final EventosRepository eventosRepository;

    public Eventos(EventosRepository eventosRepository) {
        this.eventosRepository = eventosRepository;
    }
}
