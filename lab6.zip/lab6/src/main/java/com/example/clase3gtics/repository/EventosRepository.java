package com.example.clase3gtics.repository;

import com.example.clase3gtics.controller.Eventos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EventosRepository extends JpaRepository<Eventos, Integer> {

    @Query(value= "SELECT e.eventoId, e.nombre AS nombreEvento, e.fecha, e.asistentesEsperados, a.artistaId, a.nombre AS nombreArtista " +
            "FROM eventos e " +
            "LEFT JOIN eventos_artistas ea ON e.eventoId = ea.eventoId " +
            "LEFT JOIN artistas a ON ea.artistaId = a.artistaId",
            nativeQuery = true)
    List<Eventos> listarEventosConArtistas();
}
