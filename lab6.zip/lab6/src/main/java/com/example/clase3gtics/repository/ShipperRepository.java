package com.example.clase3gtics.repository;

import com.example.clase3gtics.entity.Artistas;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface    ShipperRepository extends JpaRepository<Artistas, Integer> {

    List<Artistas> findByCompanyName(String name);

    List<Artistas> findByCompanyNameOrPhone(String n, String p);

    @Query(nativeQuery = true,value = "select * from shippers where CompanyName = ?1")
    List<Artistas> buscarPorNombre(String nombre);

    @Query(nativeQuery = true, value = "select * from shippers where CompanyName like %?1%")
    List<Artistas> buscarParcialPorNombre(String nombre);

}

